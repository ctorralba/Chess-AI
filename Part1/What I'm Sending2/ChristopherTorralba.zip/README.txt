Under the christophertorralba directory
To run use the commands
make
./testRun <insert-name> --gameSettings fen="<insert-fen>"


All the actions for the currently selected piece is printed
through standard output. (cout)