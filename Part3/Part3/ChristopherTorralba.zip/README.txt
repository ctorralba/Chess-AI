Under the christophertorralba directory
To run use the commands
make
./testRun <insert-name> --gameSettings fen="<insert-fen>"


Time Limited Iterative-Deepening Depth-Limited MiniMax with alpha beta prunning is located at the bottom of state.hpp