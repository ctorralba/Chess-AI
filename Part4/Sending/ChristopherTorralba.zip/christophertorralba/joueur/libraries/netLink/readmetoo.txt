This is a cut-down version of the library netLink
This library can be found at https://github.com/Lichtso/netLink
