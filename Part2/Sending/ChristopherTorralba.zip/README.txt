Under the christophertorralba directory
To run use the commands
make
./testRun <insert-name> --gameSettings fen="<insert-fen>"


Iterative-Deepening Depth-Limited MiniMax is located at the bottom of state.hpp